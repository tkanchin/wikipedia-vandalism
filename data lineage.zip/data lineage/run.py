"""
Simple Data Lineage Tracer

A minimal implementation of a data lineage tracer that identifies column lineage
across multiple databases without visualizations or complex reporting.
"""

import os
import argparse
from typing import Dict, List, Any, Tuple

from helpers import (
    process_sql_files,
    create_vector_store,
    check_file_exists
)
from llm import LineageLLM

class SimpleLineageTracer:
    """A simplified data lineage tracer using FAISS."""
    
    def __init__(
        self,
        db1_path: str,
        db2_path: str,
        llm_model: str = "gpt-4o",
        embedding_model: str = "text-embedding-ada-002"
    ):
        """
        Initialize the lineage tracer.
        
        Args:
            db1_path: Path to the user-facing database SQL folder
            db2_path: Path to the backend database SQL folder
            llm_model: Model name for the LLM
            embedding_model: Model name for embeddings
        """
        self.db1_path = db1_path
        self.db2_path = db2_path
        self.embedding_model = embedding_model
        
        # Initialize LLM analyzer
        self.llm_analyzer = LineageLLM(llm_model)
        
        # Process database files
        print(f"Processing files from {db1_path} and {db2_path}...")
        self.db1_files = process_sql_files(db1_path, "db1")
        self.db2_files = process_sql_files(db2_path, "db2")
        
        print(f"DB1 files: {', '.join(self.db1_files.keys())}")
        print(f"DB2 files: {', '.join(self.db2_files.keys())}")
        
        # Build vector store for DB1 only (we only search in DB1)
        print("Building vector store using FAISS...")
        self.db1_vectorstore = create_vector_store(
            self.db1_files, "db1", embedding_model
        )
        
        print("Setup complete. Ready for lineage tracing.")
    
    def trace_lineage(self, column_info: List[Tuple[str, str]]):
        """
        Trace the lineage for multiple business columns.
        
        Args:
            column_info: List of tuples containing (business_column_name, business_column_description)
        """
        for business_name, description in column_info:
            print(f"\nTracing lineage for: '{business_name}' - '{description}'")
            
            # Get multiple possible DB1 matches and their source mappings
            matches = self.llm_analyzer.analyze_column_lineage(
                business_name,
                description, 
                self.db1_vectorstore,
                self.db1_files
            )
            
            match_counter = 0
            # Process each potential match
            for db1_match, source_mappings in matches:
                match_counter += 1
                confidence = db1_match.get("confidence", "unknown")
                reasoning = db1_match.get("reasoning", "")
                
                if db1_match.get("table") == "unknown":
                    print(f"  Match {match_counter}: No valid match found in DB1")
                    continue
                
                db1_path = f"db1.{db1_match['table']}.{db1_match['column']}"
                print(f"  Match {match_counter}: {db1_path} (Confidence: {confidence})")
                if reasoning:
                    print(f"    Reasoning: {reasoning}")
                
                # If no source mappings were found
                if not source_mappings:
                    print(f"    No source mappings found for {db1_path}")
                    # Display the lineage with empty source
                    print(f"    LINEAGE: {business_name} ({description}) -> {db1_path} -> (no source found)")
                    continue
                
                # For each source, check if it exists in DB2
                for i, source in enumerate(source_mappings, 1):
                    source_table = source["source_table"]
                    source_column = source["source_column"]
                    transformation = source.get("transformation", "")
                    
                    # Check if the source table exists in DB2
                    source_exists = check_file_exists(source_table, self.db2_files)
                    
                    db2_path = f"db2.{source_table}.{source_column}"
                    if source_exists:
                        # Display the full lineage
                        print(f"    LINEAGE {match_counter}.{i}: {business_name} ({description}) -> {db1_path} -> {db2_path}")
                    else:
                        # Display the partial lineage
                        print(f"    LINEAGE {match_counter}.{i}: {business_name} ({description}) -> {db1_path} -> {db2_path} (not verified)")
                    
                    # Print transformation if available
                    if transformation:
                        print(f"      Transformation: {transformation}")

def main():
    """Main function to run the lineage tracer."""        
    # Create and run the tracer

    column_info = [
            ("Customer Email", "Email address used for customer communication"),
            ("Monthly Revenue", "Total revenue generated each month")
        ]

    tracer = SimpleLineageTracer("database1", "database2")
    tracer.trace_lineage(column_info)

if __name__ == "__main__":
    main()