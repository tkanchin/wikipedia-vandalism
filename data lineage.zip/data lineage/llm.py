"""
LLM-based analysis functions for data lineage.
"""

import json
from typing import Dict, List, Any, Tuple

from langchain_community.chat_models import ChatOpenAI
from langchain.schema import HumanMessage
from langchain_community.vectorstores import FAISS

class LineageLLM:
    """Class for LLM-based lineage analysis."""
    
    def __init__(self, model_name: str = "gpt-4o"):
        """
        Initialize the LineageLLM.
        
        Args:
            model_name: Name of the LLM model to use
        """
        self.llm = ChatOpenAI(model_name=model_name, temperature=0)
    
    def analyze_column_lineage(self, 
                              business_name: str,
                              description: str, 
                              vectorstore: FAISS,
                              db1_files: Dict[str, Dict]) -> List[Tuple[Dict[str, str], List[Dict[str, str]]]]:
        """
        Perform comprehensive lineage analysis in a single LLM call.
        
        Args:
            business_name: Business name of the column
            description: Description of the column to find
            vectorstore: FAISS vector store for DB1
            db1_files: Dictionary of DB1 files
            
        Returns:
            List of tuples, each containing (table match dict, source mappings list)
        """
        # Retrieve relevant SQL chunks from the vector store
        search_query = f"{business_name} {description}"
        docs = vectorstore.similarity_search(search_query, k=7)  # Increased to get more context
        context = "\n\n".join([doc.page_content for doc in docs])
        
        # Get all metadata for debugging
        metadata_list = [doc.metadata for doc in docs]
        print(f"  Found metadata: {metadata_list}")
        
        # Get filenames to help with lookup
        filenames = [meta["filename"] for meta in metadata_list]
        
        # Find the most likely SQL files (up to top 3)
        filenames_count = {}
        for filename in filenames:
            filenames_count[filename] = filenames_count.get(filename, 0) + 1
        
        top_files = sorted(filenames_count.items(), key=lambda x: x[1], reverse=True)[:3]
        top_file_contents = {}
        
        # Get contents of top files for better analysis
        for filename, _ in top_files:
            if filename in db1_files:
                top_file_contents[filename] = db1_files[filename]["content"]
                print(f"  Using content of {filename} for analysis")
        
        # Build additional content section
        additional_content = ""
        for filename, content in top_file_contents.items():
            # Limit content length to prevent token overflow
            truncated_content = content[:3000]
            additional_content += f"\nFull content of {filename}:\n{truncated_content}\n"
        
        # Format the prompt to identify multiple matches
        prompt = f"""
        I need to trace the data lineage for a business column:
        
        Business Column Name: "{business_name}"
        Business Column Description: "{description}"
        
        Based on these SQL file chunks:
        
        {context}
        
        {additional_content}
        
        I need you to identify:
        
        1. ALL possible tables and columns in the database that might match this business column.
           For each potential match, assign a confidence score (high, medium, or low).
        
        2. For each identified table/column, analyze where its data comes from (source tables and columns).
        
        Important note: In our system, the SQL filenames match their table names (e.g., customer_profile.sql defines the customer_profile table).
        
        Analyze the SQL to find:
        - All technical column names that could correspond to the business column
        - FROM clauses that identify source tables
        - JOIN clauses that connect to other tables
        - Any transformations applied to the data
        
        Return ONLY a JSON object in this format:
        ```json
        {{
          "matches": [
            {{
              "table_match": {{
                "table": "table_name",
                "column": "column_name",
                "confidence": "high/medium/low",
                "reasoning": "brief explanation of why this matches"
              }},
              "source_mappings": [
                {{
                  "source_table": "source_table_name",
                  "source_column": "source_column_name",
                  "transformation": "brief description of any transformation"
                }}
              ]
            }}
          ]
        }}
        ```
        
        You MUST include at least one match with its source mappings. If no source mappings can be identified for a match, return an empty array for that match's source_mappings.
        """
        
        response = self.llm.invoke([HumanMessage(content=prompt)])
        result = response.content
        
        # Parse result
        try:
            # Clean the result
            result = result.strip()
            if result.startswith("```json"):
                result = result[7:].strip()
            if result.endswith("```"):
                result = result[:-3].strip()
            
            parsed_result = json.loads(result)
            print(f"  Analysis found {len(parsed_result.get('matches', []))} potential matches")
            
            # Process matches
            processed_matches = []
            
            for match_data in parsed_result.get("matches", []):
                table_match = match_data.get("table_match", {})
                source_mappings = match_data.get("source_mappings", [])
                
                # Add filename to the table match
                if "table" in table_match:
                    table_match["filename"] = f"{table_match['table']}.sql"
                else:
                    table_match = {"table": "unknown", "column": "unknown", "filename": "unknown.sql", "confidence": "low"}
                
                processed_matches.append((table_match, source_mappings))
            
            # If no matches, add a default unknown match
            if not processed_matches:
                processed_matches.append((
                    {"table": "unknown", "column": "unknown", "filename": "unknown.sql", "confidence": "low"},
                    []
                ))
            
            return processed_matches
            
        except Exception as e:
            # Fallback if parsing fails
            print(f"Failed to parse response: {result}")
            print(f"Error: {str(e)}")
            return [({"table": "unknown", "column": "unknown", "filename": "unknown.sql", "confidence": "low"}, [])]