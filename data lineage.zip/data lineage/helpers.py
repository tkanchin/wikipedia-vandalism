"""
Helper functions for SQL file processing and data manipulation.
"""
import os
from pathlib import Path
from typing import Dict, List

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

def process_sql_files(folder_path: str, db_name: str) -> Dict[str, Dict]:
    """
    Process SQL files in a folder.
    
    Args:
        folder_path: Path to the folder containing SQL files
        db_name: Name of the database these files belong to
        
    Returns:
        Dictionary mapping filenames to their content and metadata
    """
    results = {}
    
    for file_path in Path(folder_path).glob("**/*.sql"):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
            results[file_path.name] = {
                "content": content,
                "filename": file_path.name,
                "path": str(file_path),
                "database": db_name
            }
    
    print(f"Processed {len(results)} SQL files from {folder_path}")
    return results

def create_vector_store(sql_files: Dict[str, Dict], 
                       db_name: str, 
                       embedding_model: str = "text-embedding-ada-002") -> FAISS:
    """
    Create a FAISS vector store from SQL files.
    
    Args:
        sql_files: Dictionary mapping filenames to their content
        db_name: Name of the database
        embedding_model: Name of the embedding model to use
        
    Returns:
        FAISS vector store containing the SQL files
    """
    # Create embeddings model
    embeddings = OpenAIEmbeddings(model=embedding_model)
    
    # Create text splitter
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1500,
        chunk_overlap=200
    )
    
    # Process files into documents
    texts = []
    metadatas = []
    
    for filename, file_data in sql_files.items():
        chunks = text_splitter.split_text(file_data["content"])
        
        for chunk in chunks:
            texts.append(chunk)
            metadatas.append({
                "filename": filename,
                "database": db_name
            })
    
    # Create FAISS vector store (in-memory)
    if not texts:
        # Handle empty case
        print(f"Warning: No text chunks found for {db_name}")
        # Create a dummy document to initialize FAISS
        texts = ["Empty database"]
        metadatas = [{"filename": "empty.sql", "database": db_name}]
        
    vectorstore = FAISS.from_texts(
        texts=texts,
        embedding=embeddings,
        metadatas=metadatas
    )
    
    return vectorstore

def check_file_exists(table_name: str, db_files: Dict[str, Dict]) -> bool:
    """
    Check if a file exists for a given table name.
    
    Args:
        table_name: Name of the table to check
        db_files: Dictionary of database files
        
    Returns:
        True if a file exists for this table, False otherwise
    """
    # Check for exact filename match (with .sql extension)
    if f"{table_name}.sql" in db_files:
        return True
    
    # Check for filename match ignoring case
    for filename in db_files.keys():
        if filename.lower() == f"{table_name.lower()}.sql":
            return True
    
    return False

