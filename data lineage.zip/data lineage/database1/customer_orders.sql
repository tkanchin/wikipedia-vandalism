
-- Customer Orders View
-- This view links customers with their ordered products
CREATE OR REPLACE VIEW customer_orders AS
SELECT
    order_id,                    -- Unique identifier for each order
    customer_id,                 -- Customer who placed the order
    order_date,                  -- Date when order was placed
    product_id,                  -- Product that was ordered
    quantity,                    -- Quantity of product ordered
    unit_price,                  -- Price per unit at time of order
    total_price,                 -- Total price for this line item
    shipping_address,            -- Address where order was shipped
    shipping_status,             -- Current status of shipping
    delivery_date                -- Actual or expected delivery date
FROM
    orders_data
JOIN
    order_details ON orders_data.order_id = order_details.order_id;
        