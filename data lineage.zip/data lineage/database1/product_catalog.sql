
-- Product Catalog View
-- This view contains all products available for purchase
CREATE OR REPLACE VIEW product_catalog AS
SELECT
    product_id,                  -- Unique identifier for each product
    product_name,                -- Name of the product
    product_description,         -- Detailed description of the product
    category,                    -- Product category
    subcategory,                 -- Product subcategory
    brand,                       -- Brand of the product
    retail_price,                -- Current retail price
    discount_price,              -- Discounted price (if applicable)
    inventory_count,             -- Current inventory level
    reorder_threshold,           -- Threshold at which to reorder inventory
    supplier_id                  -- ID of the supplier for this product
FROM
    product_master;
        