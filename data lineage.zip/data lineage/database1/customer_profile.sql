
-- Customer Profile View
-- This view contains customer demographic and account information
CREATE OR REPLACE VIEW customer_profile AS
SELECT
    customer_id,                 -- Unique identifier for each customer
    first_name,                  -- Customer's first name
    last_name,                   -- Customer's last name
    email,                       -- Customer's email address
    phone_number,                -- Customer's contact number
    date_of_birth,               -- Customer's date of birth
    registration_date,           -- Date when customer registered
    loyalty_tier,                -- Customer loyalty program tier (bronze, silver, gold, platinum)
    total_spend,                 -- Total amount spent by customer to date
    preferred_payment_method     -- Customer's most frequently used payment method
FROM
    customer_base_data;
        