
-- Transaction Summary View
-- This view provides a summary of all customer transactions
CREATE OR REPLACE VIEW transaction_summary AS
SELECT
    transaction_id,              -- Unique identifier for each transaction
    customer_id,                 -- Customer who made the transaction
    transaction_date,            -- Date when transaction occurred
    transaction_amount,          -- Total monetary value of the transaction
    payment_method,              -- Method used for payment (credit card, debit card, etc)
    store_id,                    -- Store where transaction occurred
    product_count,               -- Number of products in the transaction
    discount_applied,            -- Whether any discount was applied
    loyalty_points_earned        -- Loyalty points earned from this transaction
FROM
    raw_transactions
WHERE
    transaction_status = 'completed';
        