
-- Store Performance View
-- This view provides metrics on store performance
CREATE OR REPLACE VIEW store_performance AS
SELECT
    store_id,                    -- Unique identifier for each store
    store_name,                  -- Name of the store
    region,                      -- Geographical region of the store
    store_manager,               -- Name of the store manager
    total_sales,                 -- Total sales for the time period
    transaction_count,           -- Number of transactions for the time period
    average_transaction_value,   -- Average value per transaction
    year_over_year_growth,       -- Growth compared to same period last year
    top_selling_category,        -- Category with highest sales
    customer_satisfaction_score  -- Average customer satisfaction rating
FROM
    store_metrics
JOIN
    regional_metrics ON store_metrics.region_id = regional_metrics.region_id;
        