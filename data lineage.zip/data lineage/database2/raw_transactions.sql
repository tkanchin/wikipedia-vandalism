
-- Raw Transactions Table
-- This table consolidates transaction data from multiple POS systems
CREATE TABLE raw_transactions AS
SELECT
    CONCAT('TX-', pos.transaction_key) AS transaction_id,
    pos.customer_key AS customer_id,
    pos.transaction_timestamp AS transaction_date,
    pos.total_amount AS transaction_amount,
    pos.payment_method_code AS payment_method,
    pos.store_key AS store_id,
    pos.item_count AS product_count,
    CASE WHEN pos.discount_total > 0 THEN true ELSE false END AS discount_applied,
    FLOOR(pos.total_amount * loyalty.points_multiplier) AS loyalty_points_earned,
    pos.status_code AS transaction_status
FROM
    source_system_5.point_of_sale_transactions AS pos
LEFT JOIN
    source_system_2.loyalty_rules AS loyalty ON pos.transaction_date BETWEEN loyalty.start_date AND loyalty.end_date;
        