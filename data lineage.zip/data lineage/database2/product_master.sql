
-- Product Master Table
-- This table contains the definitive product data from the ERP system
CREATE TABLE product_master AS
SELECT
    erp.product_code AS product_id,
    erp.product_name AS product_name,
    erp.long_description AS product_description,
    cat.primary_category AS category,
    cat.secondary_category AS subcategory,
    erp.manufacturer AS brand,
    pricing.current_price AS retail_price,
    pricing.promotional_price AS discount_price,
    inventory.stock_on_hand AS inventory_count,
    inventory.reorder_level AS reorder_threshold,
    erp.vendor_id AS supplier_id
FROM
    source_system_6.erp_products AS erp
JOIN
    source_system_7.product_categories AS cat ON erp.product_code = cat.product_code
JOIN
    source_system_8.price_management AS pricing ON erp.product_code = pricing.product_code
JOIN
    source_system_9.inventory_management AS inventory ON erp.product_code = inventory.product_code;
        