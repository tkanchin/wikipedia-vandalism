
-- Orders Data Table
-- This table contains header information for customer orders
CREATE TABLE orders_data AS
SELECT
    ecom.order_number AS order_id,
    ecom.user_id AS customer_id,
    ecom.purchase_timestamp AS order_date,
    ecom.shipping_street || ', ' || ecom.shipping_city || ', ' || ecom.shipping_state || ' ' || ecom.shipping_zipcode AS shipping_address,
    shipment.status_description AS shipping_status,
    shipment.actual_delivery_date AS delivery_date
FROM
    source_system_10.e_commerce_orders AS ecom
LEFT JOIN
    source_system_11.shipping_details AS shipment ON ecom.order_number = shipment.order_reference;
        