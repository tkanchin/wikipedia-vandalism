
-- Regional Metrics Table
-- This table provides regional-level performance metrics
CREATE TABLE regional_metrics AS
SELECT
    region.region_code AS region_id,
    region.region_name AS region,
    surveys.satisfaction_score AS customer_satisfaction_score
FROM
    source_system_15.geographical_regions AS region
JOIN
    source_system_16.customer_survey_results AS surveys ON region.region_code = surveys.region_code
WHERE
    surveys.survey_date BETWEEN DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH) AND CURRENT_DATE;
        