
-- Order Details Table
-- This table contains line item details for customer orders
CREATE TABLE order_details AS
SELECT
    ecom_items.order_number AS order_id,
    ecom_items.product_code AS product_id,
    ecom_items.quantity AS quantity,
    ecom_items.unit_price AS unit_price,
    ecom_items.quantity * ecom_items.unit_price AS total_price
FROM
    source_system_10.e_commerce_order_items AS ecom_items;
        