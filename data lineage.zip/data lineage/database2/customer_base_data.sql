
-- Customer Base Data Table
-- This table contains raw customer data from multiple source systems
CREATE TABLE customer_base_data AS
SELECT
    cust.id AS customer_id,
    cust.fname AS first_name,
    cust.lname AS last_name,
    cust.email_address AS email,
    cust.phone AS phone_number,
    cust.birth_date AS date_of_birth,
    cust.reg_date AS registration_date,
    loyalty.tier_name AS loyalty_tier,
    finance.total_customer_spend AS total_spend,
    pref.payment_type AS preferred_payment_method
FROM
    source_system_1.customers AS cust
LEFT JOIN
    source_system_2.customer_loyalty AS loyalty ON cust.id = loyalty.customer_id
LEFT JOIN
    source_system_3.financial_summary AS finance ON cust.id = finance.customer_id
LEFT JOIN
    (SELECT 
        customer_id,
        payment_type,
        ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY COUNT(*) DESC) as rank
     FROM source_system_4.payment_transactions
     GROUP BY customer_id, payment_type) AS pref ON cust.id = pref.customer_id AND pref.rank = 1;
        