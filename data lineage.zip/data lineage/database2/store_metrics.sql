
-- Store Metrics Table
-- This table aggregates performance metrics for physical stores
CREATE TABLE store_metrics AS
SELECT
    store.store_code AS store_id,
    store.store_name AS store_name,
    store.region_code AS region_id,
    store.manager_name AS store_manager,
    sales.total_revenue AS total_sales,
    sales.transaction_count AS transaction_count,
    sales.total_revenue / NULLIF(sales.transaction_count, 0) AS average_transaction_value,
    (sales.total_revenue / NULLIF(prev_sales.total_revenue, 0) - 1) * 100 AS year_over_year_growth,
    top_cat.category_name AS top_selling_category
FROM
    source_system_12.store_directory AS store
JOIN
    (SELECT 
        store_code, 
        SUM(sale_amount) AS total_revenue,
        COUNT(*) AS transaction_count
     FROM source_system_13.sales_transactions
     WHERE transaction_date BETWEEN DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH) AND CURRENT_DATE
     GROUP BY store_code) AS sales ON store.store_code = sales.store_code
LEFT JOIN
    (SELECT 
        store_code, 
        SUM(sale_amount) AS total_revenue
     FROM source_system_13.sales_transactions
     WHERE transaction_date BETWEEN DATE_SUB(CURRENT_DATE, INTERVAL 13 MONTH) AND DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)
     GROUP BY store_code) AS prev_sales ON store.store_code = prev_sales.store_code
LEFT JOIN
    (SELECT 
        store_code,
        category_name,
        ROW_NUMBER() OVER (PARTITION BY store_code ORDER BY SUM(sale_amount) DESC) as rank
     FROM source_system_13.sales_transactions
     JOIN source_system_14.product_hierarchy ON sales_transactions.product_code = product_hierarchy.product_code
     WHERE transaction_date BETWEEN DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH) AND CURRENT_DATE
     GROUP BY store_code, category_name) AS top_cat ON store.store_code = top_cat.store_code AND top_cat.rank = 1;
        