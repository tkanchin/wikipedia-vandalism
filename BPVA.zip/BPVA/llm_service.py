import json
from langchain.chat_models import ChatOpenAI
from langchain.schema import HumanMessage, SystemMessage

class LLMService:
    """Service for LLM interactions"""
    
    def __init__(self, model_name="gpt-4"):
        """Initialize with model name"""
        self.llm = ChatOpenAI(model_name=model_name)
    
    def name_clusters(self, clusters_to_articles):
        """
        Use LLM to name clusters
        clusters_to_articles: dict mapping cluster IDs to lists of article titles
        """
        print("Naming clusters with LLM...")
        
        cluster_names = {}
        
        for cluster, articles in clusters_to_articles.items():
            articles_text = "\n".join(articles)
            
            system_message = """You are an expert in categorizing and naming content groups.
            I have a cluster of Wikipedia article titles, and I need you to create a descriptive category name that 
            encompasses all these articles. Provide a short, clear category name (3-5 words) that accurately describes this group."""
            
            messages = [
                SystemMessage(content=system_message),
                HumanMessage(content=f"Here are the article titles in this cluster:\n{articles_text}\n\nPlease provide only the category name and nothing else.")
            ]
            
            name = self.llm.predict_messages(messages).content.strip()
            cluster_names[cluster] = name
            print(f"Cluster {cluster} named: {name}")
        
        return cluster_names

    def rerank_with_disambiguation(self, query, article_info, cluster_articles):
        """
        Use LLM to determine if disambiguation is needed and rerank results
        
        Args:
            query: The user's search query
            article_info: List of dicts with article information
            cluster_articles: Dict mapping clusters to article lists
            
        Returns:
            top_article: Title of the top article
            needs_disambiguation: Boolean indicating if disambiguation is needed
            disambiguation_question: A question to clarify ambiguity, if needed
            explanation: Explanation of the decision
        """
        system_message = """You are an expert search assistant with advanced disambiguation capabilities.
        You're given a user query and the top retrieved articles grouped by their categories. Your task is to:
        
        1. Determine if the query is ambiguous and if disambiguation is needed
        2. If disambiguation is needed, create a helpful clarifying question that explicitly mentions the different categories and their child articles
        3. If no disambiguation is needed, select the most relevant article
        
        Consider a query ambiguous if:
        - The query could apply to multiple different topics
        - The top results span different subject areas or categories
        - The intent behind the query isn't clear
        
        For the disambiguation question:
        - Explicitly structure the question to highlight the cluster hierarchy
        - Mention the category names followed by example articles in each category
        - Make it clear that you're asking which category or specific article they're interested in
        
        Your response must be a JSON object with these fields:
        - needs_disambiguation: boolean
        - top_article: the title of the most relevant article 
        - disambiguation_question: a helpful question if disambiguation is needed (or null)
        - explanation: brief explanation of your decision
        """
        
        query_context = {
            "query": query,
            "top_articles": article_info,
            "clusters": cluster_articles
        }
        
        messages = [
            SystemMessage(content=system_message),
            HumanMessage(content=json.dumps(query_context, indent=2))
        ]
        
        response = self.llm.predict_messages(messages).content
        
        # Parse JSON response
        try:
            result = json.loads(response)
            return (
                result.get("top_article"), 
                result.get("needs_disambiguation", False), 
                result.get("disambiguation_question"),
                result.get("explanation")
            )
        except json.JSONDecodeError:
            # Fallback if LLM doesn't return valid JSON
            print("Error parsing LLM response. Using fallback method.")
            return article_info[0]['title'], False, None, "Error in LLM response parsing"

    def handle_disambiguation_response(self, user_response, article_info):
        """
        Process user response to disambiguation question
        
        Args:
            user_response: The user's textual response to disambiguation
            article_info: List of dicts with article information
            
        Returns:
            selected_article: Title of the selected article
            confidence: Confidence score for the selection
            explanation: Explanation of the selection
        """
        system_message = """You are an expert search assistant that helps select the most relevant article based on a user's response to a disambiguation question.
        Given the top articles and the user's clarification, determine which article best matches their intent.
        
        Your response must be a JSON object with these fields:
        - selected_article: the title of the most relevant article based on user's clarification
        - confidence: a number between 0-1 indicating your confidence in this selection
        - explanation: brief explanation of your selection
        """
        
        context = {
            "user_response": user_response,
            "available_articles": article_info
        }
        
        messages = [
            SystemMessage(content=system_message),
            HumanMessage(content=json.dumps(context, indent=2))
        ]
        
        response = self.llm.predict_messages(messages).content
        
        # Parse JSON response
        try:
            result = json.loads(response)
            return (
                result.get("selected_article"), 
                result.get("confidence", 0.0),
                result.get("explanation")
            )
        except json.JSONDecodeError:
            # Fallback if LLM doesn't return valid JSON
            print("Error parsing LLM response. Using fallback method.")
            return article_info[0]['title'], 0.5, "Error in LLM response parsing"