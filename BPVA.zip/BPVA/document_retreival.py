import numpy as np
import faiss
from tqdm import tqdm

class DocumentRetrieval:
    """Handles document embedding, indexing, and retrieval"""
    
    def __init__(self, embeddings_provider):
        """
        Initialize with embeddings provider
        """
        self.embeddings_provider = embeddings_provider
        self.df = None
        self.chunk_embeddings = None
        self.faiss_index = None
    
    def prepare_data(self, df):
        """Load and prepare the dataset"""
        self.df = df
        print(f"Dataset loaded with {len(self.df)} chunks from {self.df['title'].nunique()} articles")
    
    def generate_embeddings(self):
        """Generate embeddings for all chunks"""
        if self.df is None:
            print("No data loaded. Call prepare_data first.")
            return
            
        print("Generating embeddings for all chunks...")
        
        texts = self.df['chunk_text'].tolist()
        self.chunk_embeddings = [self.embeddings_provider.embed_query(text) for text in tqdm(texts)]
        
        # Convert to numpy array for FAISS
        self.chunk_embeddings = np.array(self.chunk_embeddings).astype('float32')
        print(f"Generated {len(self.chunk_embeddings)} embeddings")
    
    def build_faiss_index(self):
        """Build and save FAISS index"""
        if self.chunk_embeddings is None:
            print("No embeddings generated. Call generate_embeddings first.")
            return
            
        print("Building FAISS index...")
        
        # Create FAISS index
        dimension = self.chunk_embeddings.shape[1]
        self.faiss_index = faiss.IndexFlatL2(dimension)
        self.faiss_index.add(self.chunk_embeddings)
        
        # Save index
        faiss.write_index(self.faiss_index, "chunk_index.faiss")
        print("FAISS index built and saved")
    
    def load_faiss_index(self, path="chunk_index.faiss"):
        """Load a saved FAISS index"""
        try:
            self.faiss_index = faiss.read_index(path)
            print(f"Loaded FAISS index from {path}")
            return True
        except:
            print(f"Error loading FAISS index from {path}")
            return False
    
    def retrieve_chunks(self, query, k=10):
        """Retrieve top k chunks for a query"""
        if self.faiss_index is None:
            print("No index built. Call build_faiss_index first.")
            return []
            
        # Generate embedding for query
        query_embedding = self.embeddings_provider.embed_query(query)
        query_embedding = np.array([query_embedding]).astype('float32')
        
        # Search FAISS index
        distances, indices = self.faiss_index.search(query_embedding, k)
        
        # Get corresponding chunks
        retrieved_chunks = []
        for i, idx in enumerate(indices[0]):
            retrieved_chunks.append({
                'index': idx,
                'distance': float(distances[0][i]),
                'title': self.df.iloc[idx]['title'],
                'url': self.df.iloc[idx]['url'],
                'chunk_text': self.df.iloc[idx]['chunk_text']
            })
        
        return retrieved_chunks
    
    def roll_up_to_article(self, chunks):
        """Roll up chunks to article level and get top articles"""
        # Aggregate by article
        article_scores = {}
        for chunk in chunks:
            title = chunk['title']
            if title not in article_scores:
                article_scores[title] = 0
            # Lower distance means higher similarity
            article_scores[title] += (1 / (chunk['distance'] + 1e-6))
        
        # Sort articles by score
        ranked_articles = sorted(article_scores.items(), key=lambda x: x[1], reverse=True)
        
        return ranked_articles