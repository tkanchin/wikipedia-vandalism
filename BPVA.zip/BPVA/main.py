import os
import json
from langchain.embeddings.openai import OpenAIEmbeddings

from data_processor import sample_wiki_articles
from document_retrieval import DocumentRetrieval
from clustering import DocumentClustering
from llm_service import LLMService

# Set OpenAI API key
os.environ["OPENAI_API_KEY"] = "your-api-key"

class RAGSystem:
    """Main RAG system combining all components"""
    
    def __init__(self):
        # Initialize components
        self.embeddings = OpenAIEmbeddings()
        self.retriever = DocumentRetrieval(self.embeddings)
        self.clustering = DocumentClustering(self.embeddings)
        self.llm_service = LLMService()
        
        # Data storage
        self.df = None
        
    def initialize_with_sample_data(self):
        """Load sample Wikipedia articles and prepare system"""
        print("Loading sample Wikipedia articles...")
        self.df = sample_wiki_articles()
        self.retriever.prepare_data(self.df)
        
        # Generate embeddings and build index
        self.retriever.generate_embeddings()
        self.retriever.build_faiss_index()
        
        # Cluster articles and name clusters
        article_titles = self.df['title'].unique()
        clusters = self.clustering.cluster_articles(article_titles)
        
        # Group articles by cluster for naming
        clusters_to_articles = {}
        for article, cluster in clusters.items():
            if cluster not in clusters_to_articles:
                clusters_to_articles[cluster] = []
            clusters_to_articles[cluster].append(article)
        
        # Name clusters using LLM
        cluster_names = self.llm_service.name_clusters(clusters_to_articles)
        self.clustering.save_cluster_names(cluster_names)
        
        print("System initialization complete!")
        
    def load_from_saved_state(self):
        """Load system from saved state"""
        print("Loading system from saved state...")
        
        # Try to load data
        try:
            self.df = sample_wiki_articles()  # In a real system, this would load from storage
            self.retriever.prepare_data(self.df)
            
            # Load index
            index_loaded = self.retriever.load_faiss_index()
            if not index_loaded:
                print("Failed to load index, regenerating...")
                self.retriever.generate_embeddings()
                self.retriever.build_faiss_index()
            
            # Load clusters and names
            clusters_loaded = self.clustering.load_clusters()
            names_loaded = self.clustering.load_cluster_names()
            
            if not clusters_loaded or not names_loaded:
                print("Failed to load clusters or names, regenerating...")
                self.initialize_with_sample_data()
            
            print("System loaded successfully!")
            return True
        except Exception as e:
            print(f"Error loading system: {e}")
            return False
    
    def search(self, query, k=10):
        """
        Search for documents related to query
        
        Args:
            query: User query string
            k: Number of chunks to retrieve
            
        Returns:
            Dictionary with search results and disambiguation info
        """
        print(f"Searching for: {query}")
        
        # Retrieve chunks
        chunks = self.retriever.retrieve_chunks(query, k=k)
        
        # Roll up to article level
        ranked_articles = self.retriever.roll_up_to_article(chunks)
        top_articles = ranked_articles[:3]  # Consider top 3 for disambiguation
        
        # Get article info with clusters
        article_info = []
        for title, score in top_articles:
            cluster = self.clustering.get_cluster_for_article(title)
            cluster_name = self.clustering.get_cluster_name(cluster)
            
            # Find the URL for this article
            article_url = None
            for chunk in chunks:
                if chunk['title'] == title:
                    article_url = chunk['url']
                    break
                    
            # Get a relevant chunk snippet
            relevant_chunks = [c for c in chunks if c['title'] == title]
            relevant_chunks.sort(key=lambda x: x['distance'])
            snippet = relevant_chunks[0]['chunk_text'][:200] + "..." if relevant_chunks else ""
            
            article_info.append({
                'title': title,
                'score': float(score),
                'cluster': cluster,
                'cluster_name': cluster_name,
                'url': article_url,
                'snippet': snippet
            })
        
        # Group articles by cluster for disambiguation
        cluster_articles = {}
        for info in article_info:
            cluster = info['cluster']
            if cluster not in cluster_articles:
                cluster_articles[cluster] = {
                    'name': info['cluster_name'],
                    'articles': []
                }
            cluster_articles[cluster]['articles'].append(info['title'])
        
        # Use LLM to determine if disambiguation is needed
        top_article, needs_disambiguation, disambiguation_question, explanation = self.llm_service.rerank_with_disambiguation(
            query, article_info, cluster_articles
        )
        
        # Prepare result
        result = {
            'query': query,
            'top_article': top_article,
            'needs_disambiguation': needs_disambiguation,
            'disambiguation_question': disambiguation_question,
            'explanation': explanation,
            'ranked_articles': article_info,
            'clusters': cluster_articles
        }
        
        return result
    
    def handle_disambiguation_response(self, user_response, search_result):
        """
        Process user response to disambiguation question
        
        Args:
            user_response: User's text response to disambiguation
            search_result: The original search result dict
            
        Returns:
            Dictionary with selected article info
        """
        article_info = search_result['ranked_articles']
        
        selected_article, confidence, explanation = self.llm_service.handle_disambiguation_response(
            user_response, article_info
        )
        
        # Find full info for selected article
        selected_info = None
        for info in article_info:
            if info['title'] == selected_article:
                selected_info = info
                break
        
        result = {
            'selected_article': selected_article,
            'confidence': confidence,
            'explanation': explanation,
            'article_info': selected_info
        }
        
        return result
    
    def print_cluster_info(self):
        """Print information about clusters"""
        print("\nCluster Information:")
        
        cluster_articles = self.clustering.get_articles_by_cluster()
        
        for cluster, info in cluster_articles.items():
            print(f"Cluster {cluster}: {info['name']}")
            print(f"  Articles: {', '.join(info['articles'])}")

def run_interactive_demo():
    """Run an interactive demo of the RAG system"""
    print("Initializing RAG System...")
    rag = RAGSystem()
    
    # Try to load from saved state, initialize if failed
    if not rag.load_from_saved_state():
        rag.initialize_with_sample_data()
    
    # Print cluster information
    rag.print_cluster_info()
    
    # Interactive search loop
    print("\n=== RAG Search System ===")
    print("Type 'exit' to quit")
    
    while True:
        query = input("\nEnter your search query: ")
        if query.lower() == 'exit':
            break
        
        # Perform search
        result = rag.search(query)
        
        print(f"\nTop article: {result['top_article']}")
        print(f"Explanation: {result['explanation']}")
        
        if result['needs_disambiguation']:
            print("\nDisambiguation needed!")
            print(f"Question: {result['disambiguation_question']}")
            
            # Get user response
            user_response = input("\nYour clarification: ")
            
            # Process response
            disambiguation_result = rag.handle_disambiguation_response(user_response, result)
            
            print(f"\nSelected article: {disambiguation_result['selected_article']}")
            print(f"Confidence: {disambiguation_result['confidence']:.2f}")
            print(f"Explanation: {disambiguation_result['explanation']}")
        else:
            print("\nNo disambiguation needed.")

def run_example_queries():
    """Run example queries to demonstrate the RAG system"""
    print("Initializing RAG System...")
    rag = RAGSystem()
    
    # Try to load from saved state, initialize if failed
    if not rag.load_from_saved_state():
        rag.initialize_with_sample_data()
    
    # Print cluster information
    rag.print_cluster_info()
    
    # Example queries - both clear and ambiguous
    example_queries = [
        # Clear queries
        "Who is Count Dracula and what powers does he have?",
        "Tell me about Bruce Springsteen's album The River",
        "What is Black Widow's background in Marvel?",
        
        # Ambiguous queries
        "Dracula",
        "The River",
        "Vampires in literature"
    ]
    
    # Test several queries
    print("\n========== TESTING QUERIES ==========")
    for query in example_queries:
        print(f"\nQuery: {query}")
        
        # Perform search
        result = rag.search(query)
        
        print(f"\nTop article: {result['top_article']}")
        print(f"Explanation: {result['explanation']}")
        
        if result['needs_disambiguation']:
            print("\nDisambiguation needed!")
            print(f"Question: {result['disambiguation_question']}")
            
            # For ambiguous queries, simulate both possible responses
            # 1. Choosing the top article
            simulated_response = f"I'm interested in {result['top_article']}"
            print(f"\nSimulated response 1: {simulated_response}")
            
            disambiguation_result = rag.handle_disambiguation_response(simulated_response, result)
            
            print(f"Selected article: {disambiguation_result['selected_article']}")
            print(f"Confidence: {disambiguation_result['confidence']:.2f}")
            print(f"Explanation: {disambiguation_result['explanation']}")
            
            # 2. Choosing a different article if available
            if len(result['ranked_articles']) > 1:
                alternative_article = result['ranked_articles'][1]['title']
                simulated_response = f"I'm interested in {alternative_article}"
                print(f"\nSimulated response 2: {simulated_response}")
                
                disambiguation_result = rag.handle_disambiguation_response(simulated_response, result)
                
                print(f"Selected article: {disambiguation_result['selected_article']}")
                print(f"Confidence: {disambiguation_result['confidence']:.2f}")
                print(f"Explanation: {disambiguation_result['explanation']}")
        else:
            print("\nNo disambiguation needed.")

if __name__ == "__main__":
    # Choose mode:
    # run_interactive_demo()  # Interactive command-line interface
    run_example_queries()     # Run example queries