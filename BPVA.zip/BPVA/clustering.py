import numpy as np
from sklearn.cluster import KMeans
import pickle
from tqdm import tqdm
import matplotlib.pyplot as plt

class DocumentClustering:
    """Handles clustering of articles based on embeddings"""
    
    def __init__(self, embeddings_provider):
        """
        Initialize with an embeddings provider that has an embed_query method
        """
        self.embeddings_provider = embeddings_provider
        self.article_clusters = None
        self.cluster_names = None
    
    def cluster_articles(self, article_titles, max_clusters=10):
        """
        Cluster articles based on their titles using elbow method
        Returns a dictionary mapping titles to cluster IDs
        """
        print("Clustering article titles...")
        
        # Get unique article titles
        unique_titles = list(set(article_titles))
        print(f"Found {len(unique_titles)} unique article titles")
        
        # Generate embeddings for titles
        title_embeddings = [self.embeddings_provider.embed_query(title) for title in tqdm(unique_titles)]
        title_embeddings = np.array(title_embeddings).astype('float32')
        
        # Use elbow method to find optimal number of clusters
        distortions = []
        K_range = range(1, min(max_clusters, len(unique_titles)) + 1)
        
        for k in K_range:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            kmeans.fit(title_embeddings)
            distortions.append(kmeans.inertia_)
        
        # Calculate the rate of decrease in distortion
        deltas = np.zeros(len(distortions) - 1)
        for i in range(len(deltas)):
            deltas[i] = distortions[i] - distortions[i+1]
        
        # Find the elbow point (where the rate of decrease slows down significantly)
        elbow_index = 1  # Default to 2 clusters if no clear elbow
        for i in range(1, len(deltas)):
            if deltas[i-1] > 2 * deltas[i]:  # Significant drop in improvement
                elbow_index = i
                break
        
        # Add 1 to get the actual number of clusters
        optimal_clusters = K_range[elbow_index]
        
        # Plot the elbow curve
        plt.figure(figsize=(10, 6))
        plt.plot(K_range, distortions, 'bx-')
        plt.xlabel('Number of clusters (k)')
        plt.ylabel('Distortion (Inertia)')
        plt.title('Elbow Method for Optimal k')
        plt.axvline(x=optimal_clusters, color='r', linestyle='--')
        plt.savefig('elbow_curve.png')
        plt.close()
        
        print(f"Optimal number of clusters determined to be: {optimal_clusters}")
        
        # Cluster titles with optimal number of clusters
        kmeans = KMeans(n_clusters=optimal_clusters, random_state=42, n_init=10)
        clusters = kmeans.fit_predict(title_embeddings)
        
        # Create dictionary mapping titles to clusters
        self.article_clusters = {}
        for title, cluster in zip(unique_titles, clusters):
            self.article_clusters[title] = int(cluster)
            
        # Save clusters
        with open("article_clusters.pkl", "wb") as f:
            pickle.dump(self.article_clusters, f)
            
        print(f"Articles clustered into {optimal_clusters} groups")
        return self.article_clusters
    
    def save_clusters(self, filename="article_clusters.pkl"):
        """Save article clusters to file"""
        if self.article_clusters:
            with open(filename, "wb") as f:
                pickle.dump(self.article_clusters, f)
            print(f"Saved clusters to {filename}")
        else:
            print("No clusters to save")
    
    def load_clusters(self, filename="article_clusters.pkl"):
        """Load article clusters from file"""
        try:
            with open(filename, "rb") as f:
                self.article_clusters = pickle.load(f)
            print(f"Loaded clusters from {filename}")
            return self.article_clusters
        except FileNotFoundError:
            print(f"Cluster file {filename} not found")
            return None
    
    def save_cluster_names(self, cluster_names, filename="cluster_names.pkl"):
        """Save cluster names to file"""
        self.cluster_names = cluster_names
        with open(filename, "wb") as f:
            pickle.dump(cluster_names, f)
        print(f"Saved cluster names to {filename}")
    
    def load_cluster_names(self, filename="cluster_names.pkl"):
        """Load cluster names from file"""
        try:
            with open(filename, "rb") as f:
                self.cluster_names = pickle.load(f)
            print(f"Loaded cluster names from {filename}")
            return self.cluster_names
        except FileNotFoundError:
            print(f"Cluster names file {filename} not found")
            return None
    
    def get_cluster_for_article(self, article_title):
        """Get cluster for an article title"""
        if self.article_clusters:
            return self.article_clusters.get(article_title)
        return None
    
    def get_cluster_name(self, cluster_id):
        """Get name for a cluster ID"""
        if self.cluster_names:
            return self.cluster_names.get(cluster_id, "Uncategorized")
        return "Uncategorized"
    
    def get_articles_by_cluster(self):
        """Group articles by cluster"""
        if not self.article_clusters:
            return {}
            
        cluster_articles = {}
        for article, cluster in self.article_clusters.items():
            if cluster not in cluster_articles:
                cluster_articles[cluster] = {
                    'name': self.get_cluster_name(cluster),
                    'articles': []
                }
            cluster_articles[cluster]['articles'].append(article)
        
        return cluster_articles